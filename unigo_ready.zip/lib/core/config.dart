class AppConfig {
  static const appName = 'UNIGO';
  static const passengerRole = 'passenger';
  static const defaultServiceFeeShort = 25.0;
  static const defaultServiceFeeLong = 40.0;
  static const defaultPremiumPrice = 100.0;
  static const premiumLongRideFee = 10.0;
  static const defaultCurrency = 'TRY';
}
